import pickle
import numpy as np
from quantizers import kd_tree

from bigann_datasets import DATASETS
from quantizers import DeDriftPQQuantizer
from collections import Counter
from scipy.stats import special_ortho_group


# what does it cost to update CoDEQ on a single point for a dataset of size N?
def get_data_ids(node):
    return [x[1] for x in node.data]

def count_heap_deltas(orig_node, new_node):

    if orig_node.left is None and orig_node.right is None:
        return 0
    
    origleft = set(get_data_ids(orig_node.left))
    nextleft = set(get_data_ids(new_node.left))
    deltaleft = origleft.symmetric_difference(nextleft)

    origright = set(get_data_ids(orig_node.right))
    nextright = set(get_data_ids(new_node.right))
    deltaright = origright.symmetric_difference(nextright)

    return int(1.0*(len(deltaleft)>0) + 1.0*(len(deltaright)>0)) 


def count_heaps_to_update(orig_tree, new_tree):

    heap_count = 0
    node_pairs = [(orig_tree.root, new_tree.root)]

    while len(node_pairs) > 0:
        orig_node, new_node = node_pairs.pop(0)
        heap_count += count_heap_deltas(orig_node, new_node)

        if orig_node.left is not None and new_node.left is not None:
            node_pairs.append((orig_node.left, new_node.left))
        if orig_node.right is not None and new_node.right is not None:
            node_pairs.append((orig_node.right, new_node.right))

    return heap_count


def heap_count_exp(n, d, M, l, dataset_tuple=None):

    if dataset_tuple is None:
        data = np.random.normal(size=(n + 1, d))
        dataset_tuple = [(data[i,:], i) for i in range(len(data))]

    else:
        n = len(dataset_tuple)-1

    block_dim = d//M
    total_heaps = 0
    for i in range(M): # split data into blocks
        block_dataset_tuple = []
        random_matrix = special_ortho_group.rvs(block_dim)

        for data_point in dataset_tuple: # randomly rotate subvectors
            rotated_data_point = np.matmul(data_point[0][i*block_dim:(i+1)*block_dim], random_matrix)
            block_dataset_tuple.append((rotated_data_point, data_point[1]))

        dimensions = np.random.choice(block_dim, size=l, replace=False) # compute dimensions and fit kd trees
        orig_tree = kd_tree(block_dataset_tuple[:n], dimensions, l)
        next_tree = kd_tree(block_dataset_tuple, dimensions, l)
        total_heaps += count_heaps_to_update(orig_tree, next_tree)

    return total_heaps


# what does it cost to update DeDrift on a single point for a dataset of size N?
def dedrift_update_cost(dataset, n_blocks, bits_per_block, num_recluster, max_recluster_fraction=0.5):

    # initialize dedrift on dataset
    n, d = dataset.shape
    quantizer = DeDriftPQQuantizer(n, d, n_blocks, bits_per_block, 
                                   num_recluster=num_recluster, 
                                   max_recluster_fraction=max_recluster_fraction)
    dataset_tuple = [(dataset[i, :], i) for i in range(n)] 
    quantizer.initialize(dataset_tuple)

    # now scan through blocks
    unique_vector_ids = set()
    for b in range(n_blocks):
        labels = [int(x) for x in quantizer.encoded_dataset[:, b]]
        counts = Counter()
        counts.update(labels)

        # determine the clusters that need to be re-fit
        most_common_ids = [x[0] for x in counts.most_common()[:num_recluster]]
        most_common_count = sum([x[1] for x in counts.most_common()[:num_recluster]])
        new_avg_size = np.median([x[1] for x in counts.most_common()])
        k2 = np.ceil(most_common_count / new_avg_size).astype(int) 
        least_common_ids = [x[0] for x in counts.most_common()[-(k2-num_recluster):]]
        cluster_update_ids = most_common_ids+least_common_ids

        # get the unique IDs of data in these clusters
        update_ixs = []
        for ix, l in enumerate(labels):
            if any([l == id for id in cluster_update_ids]):
                update_ixs.append(ix)

        unique_vector_ids.update(update_ixs)

    return len(unique_vector_ids)


if __name__ == '__main__':

    results_path = '.'
    M = 8
    ds = DATASETS['deep-1B']()
    ds.prepare(False)

    max_recluster_fraction = 0.5

    n_trial = 10
    codebook_sizes = [4, 6, 8, 12]
    scales = range(4, 8)
    sizes = []
    for scale in scales:
        sizes += [10**scale, 5*10**scale]

    sizes = sizes[:-1]

    results = {c: {'CoDEQ': {}, 'DeDrift': {}} for c in codebook_sizes}
    for codebook_size in codebook_sizes:
        print('Codebook size {}'.format(2**codebook_size))

        for n in sizes:

            print('N = {}...'.format(n))
            results[codebook_size]['TBQ'][n] = []
            results[codebook_size]['DeDrift'][n] = []

            for _ in range(n_trial):
                # sample random dataset of size n from benchmark
                st = np.random.choice(ds.nb - n)
                data = np.array(ds.get_data_in_range(st, st+n+1))
                dataset_tuple = [(data[i,:], i) for i in range(n)]
                
                # count heaps updated
                results[codebook_size]['TBQ'][n] += [heap_count_exp(n, ds.d, M, codebook_size, dataset_tuple)]

                # count dedrift update cost
                num_recluster = int(np.ceil(0.02 * 2**codebook_size))
                results[codebook_size]['DeDrift'][n] += [dedrift_update_cost(data, M, codebook_size, num_recluster, max_recluster_fraction)]
            
            with open(results_path, 'wb') as f:
                pickle.dump(results, f)
