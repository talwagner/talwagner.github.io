import h5py
import pickle
import argparse

from tqdm.auto import tqdm
from quantizers import *

from bigann_datasets import DATASETS
from quantizers import *

from sklearn.cluster import KMeans
from dataset_construction import build_dataset_from_clustered, write_dataset_to_hdf5


def run_recall_experiment(dataset_name, 
                          dataset_path, 
                          n_blocks, 
                          bits_per_block, 
                          quantizers, 
                          n_iter, 
                          step=1, 
                          savepath=None,
                          distance_type='L2'):

    # load data
    with h5py.File(dataset_path, 'r') as f:
        documents = f[dataset_name][:]
    n, d = documents.shape

    metrics = {}
    for name, quantizer in quantizers.items():
        print(name)
        recall_metrics = {'1@1': [], '1@10': [], '1@100': [], '10@10': []}

        for i in tqdm(range(0, n_iter, step)):

            with h5py.File(dataset_path, 'r') as h:
                neighbors = h["I_" + dataset_name + "_iteration_"+str(i)][:]
                active_indices = h["active_indicies_" + dataset_name + "_iteration_"+str(i)][:]
                queries = h["queries_" + dataset_name + "_iteration_"+str(i)][:]

            current_dataset = documents[active_indices,:]
            dataset_tuple = [(current_dataset[j,:], active_indices[j]) for j in range(current_dataset.shape[0])]

            if name == 'KDTree-RR':
                quantizer = KDTreeQuantizer(n, d, n_blocks, bits_per_block, random_rotation=True, distance_type=distance_type)
                quantizer.initialize(dataset_tuple) 

            elif name == 'Oblivious': 
                quantizer = ObliviousQuantizer(n, d, n_blocks, bits_per_block, distance_type=distance_type)
                quantizer.initialize(dataset_tuple) 

            elif name in ['FrozenPQ', 'OnlinePQ']: # not incremental
                if i==0:
                    quantizer.initialize(dataset_tuple) 
                else:  
                    with h5py.File(dataset_path, 'r') as h: 
                        inserts  = h["inserts_" + dataset_name + "_iteration_"+str(i)][:]
                        deletes  = h["deletes_" + dataset_name + "_iteration_"+str(i)][:]
                    add_dataset_tuple = [(documents[insert,:], insert) for insert in inserts]
                    delete_dataset_tuple = [(documents[delete,:], delete) for delete in deletes]
                    quantizer.bulk_add(add_dataset_tuple)
                    quantizer.bulk_delete(delete_dataset_tuple)

            elif name == 'DeDriftPQ':
                if i==0:
                    quantizer.initialize(dataset_tuple)
                else: 
                    with h5py.File(dataset_path, 'r') as h: 
                        inserts  = h["inserts_" + dataset_name + "_iteration_"+str(i)][:]
                        deletes  = h["deletes_" + dataset_name + "_iteration_"+str(i)][:]
                    add_dataset_tuple = [(documents[insert,:], insert) for insert in inserts]
                    delete_dataset_tuple = [(documents[delete,:], delete) for delete in deletes]
                    quantizer.update(add_dataset_tuple, delete_dataset_tuple)
                    
            elif name == 'RebuildPQ':
                quantizer = FrozenPQQuantizer(n, d, n_blocks, bits_per_block, distance_type=distance_type)
                quantizer.initialize(dataset_tuple)

            quantizer.populate_flat()
            _, I = quantizer.search(queries, 100)

            recall_metrics['1@100'].append(np.mean(np.any(I == neighbors[:,:1], axis=1).astype(int)))
            recall_metrics['1@10'].append(np.mean(np.any(I[:, :10] == neighbors[:,:1], axis=1).astype(int)))
            recall_metrics['1@1'].append(np.mean(np.any(I[:, :1] == neighbors[:,:1], axis=1).astype(int)))
            r = np.mean([np.mean([x in neighbors[y, :10] for x in I[y, :10]]) for y in range(len(I))])
            recall_metrics['10@10'].append(r)

        metrics[name] = recall_metrics

        if savepath is not None:
            with open(savepath, 'wb') as f:
                pickle.dump(metrics, savepath)
    
    return metrics


if __name__ == "__main__":

    # experiment parameters
    dataset_name = 'deep-10M'
    dataset_size = 100000
    k = 10
    distance_type = 'L2'
    iter_per_class = 10
    query_frac=0.1
    M = 8
    L = 12
    n_dynamic_iter = 50

    # dedrift parameter
    n_recluster = 2

    # download data
    ds = DATASETS[dataset_name]()
    ds.prepare(False)
    vecs = np.array(ds.get_data_in_range(0, dataset_size)) 

    # construct dynamic search scenario
    clust = KMeans(n_clusters=k).fit(vecs)
    dataset, queryset, steps = build_dataset_from_clustered(vecs, clust, iter_per_class=iter_per_class, 
                                                            query_frac=query_frac, sort_clusters=True)

    # write to hdf5
    outdir = './data/'
    experiment_name = dataset_name+'_clustered{}'.format(k)
    write_dataset_to_hdf5(dataset, queryset, steps, experiment_name, outdir, k_nearest=100, distance_type=distance_type)


    # run recall experiment
    dataset_path = './data/{}.hdf5'.format(experiment_name)
    with h5py.File(dataset_path, 'r') as f:
        documents = f[experiment_name][:]
    n, d = documents.shape
    quantizers = {'KDTree-RR': KDTreeQuantizer(n, d, M, L, random_rotation=True, distance_type=distance_type),
                    'Oblivious': ObliviousQuantizer(n, d, M, L, distance_type=distance_type),
                    'FrozenPQ': FrozenPQQuantizer(n, d, M, L, distance_type=distance_type),
                    'OnlinePQ': OnlinePQQuantizer(n, d, M, L, distance_type=distance_type),
                    'DeDriftPQ': DeDriftPQQuantizer(n, d, M, L, num_recluster=n_recluster, max_recluster_fraction=0.5, distance_type=distance_type),
                    'RebuildPQ': FrozenPQQuantizer(n, d, M, L, distance_type=distance_type)}
    
    metrics = run_recall_experiment(dataset_name, 
                          dataset_path, 
                          M, 
                          L, 
                          quantizers, 
                          n_dynamic_iter, 
                          distance_type='L2')
