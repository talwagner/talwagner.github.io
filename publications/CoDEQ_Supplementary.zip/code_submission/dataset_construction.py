import h5py
import faiss
import os
import numpy as np


def build_dataset_from_clustered(data, clustering, iter_per_class=10, query_frac=0.1, sort_clusters=True):

    nclust = clustering.cluster_centers_.shape[0]
    labels = clustering.predict(data)

    init_data = []
    init_queries = []
    for n in range(nclust // 10):
        next_data = data[labels == n, :] # initial data and queries from ~first 10%
        cutoff = int((1-query_frac)*len(next_data))
        init_data += [next_data[:cutoff, :]]
        init_queries += [next_data[cutoff:, :]]

    dataset = [np.concatenate(init_data, axis=0)]
    queryset = [np.concatenate(init_queries, axis=0)]

    if sort_clusters: # order remaining clusters by increasing distance to initial data
        init_centroid = np.mean(dataset[0], axis=0)
        other_centroids = clustering.cluster_centers_[(n+1):, :]
        dists = [np.linalg.norm(other_centroids[i,:]-init_centroid) for i in range(other_centroids.shape[0])]
        remaining_clusters = int(n+1) + np.argsort(dists)
    else:
        remaining_clusters = [k for k in range(nclust // 10, nclust)]

    for k in remaining_clusters:
        clust_data = data[labels == k, :]
        data_splits = np.array_split(clust_data, iter_per_class)

        for next_data in data_splits: # stream subsequent classes over multiple iterations
            cutoff = int((1-query_frac)*len(next_data))
            dataset += [next_data[:cutoff, :]]
            queryset += [next_data[cutoff:, :]]

    steps = [len(x) for x in dataset]

    return dataset, queryset, steps


def write_dataset_to_hdf5(dataset, queryset, steps, dataset_name, outdir, k_nearest=100,  distance_type='L2'):
    dataset = np.concatenate(dataset)
    d = dataset.shape[1]

    dataset_output_path = os.path.join(outdir, dataset_name+'.hdf5')
    with h5py.File(dataset_output_path, 'a') as h:
        dset = h.create_dataset(dataset_name, shape = dataset.shape, data = dataset)

    num_iterations = len(queryset)
    for i in range(num_iterations):
        if distance_type == 'L2':
            my_index = faiss.IndexFlatL2(d)
        elif distance_type == 'IP':
            my_index = faiss.IndexFlatIP(d)
        queries = queryset[i]
        if i == 0: # initial data
            active_indices = [i for i in range(steps[0])]
            initial_dataset = dataset[:int(steps[0]), :]
            my_index.add(initial_dataset)
            
            curr_start = 0
            curr_end = steps[0]
        else:

            stride = steps[i]

            deletes = [x for x in range(curr_start, curr_start + stride)]
            curr_start += stride

            active_indices = list(set(active_indices) - set(deletes))

            inserts = [x for x in range(curr_end, curr_end + stride)]
            curr_end += stride
            active_indices = active_indices + inserts
            active_indices.sort()

            current_dataset = dataset[active_indices, :]
            my_index.add(current_dataset)

        _, I = my_index.search(queries, k_nearest)

        #save data of this iteration
        with h5py.File(dataset_output_path, 'a') as h:
            dset = h.create_dataset("I_" + dataset_name + "_iteration_"+str(i), shape = I.shape, data = I, dtype = 'int') 
            if i > 0:
                dset = h.create_dataset("inserts_" + dataset_name + "_iteration_"+str(i), shape = len(inserts), data = inserts, dtype = 'int') 
                dset = h.create_dataset("deletes_" + dataset_name + "_iteration_"+str(i), shape = len(deletes), data = deletes, dtype = 'int') 
            dset = h.create_dataset("active_indicies_" + dataset_name + "_iteration_"+str(i), shape = len(active_indices), data = active_indices, dtype = 'int') 
            dset = h.create_dataset("queries_" + dataset_name + "_iteration_"+str(i), shape = queries.shape, data = queries) 
        print('done iteration ' + str(i+1) + ' out of ' + str(num_iterations))
