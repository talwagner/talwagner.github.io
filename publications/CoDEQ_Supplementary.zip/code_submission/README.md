### Quantization for Nearest Neighbor Search under Dynamic Updates

This directory contains supplementary code for the ICML 2025 submission "Quantization for Nearest Neighbor Search under Dynamic Updates". The directory is structured as follows:

#### Environment
- `environment.yml` contains information on the environment used to run the experiments.

#### Code
- `quantizers.py` contains the implementation of CoDEQ (here referred to as ``KDTree") and baseline quantizers.
- `dataset_construction.py` contains code to generate dynamic search scenarios from a static benchmark dataset.

#### Scripts
- `io_cost_experiment.py` generates the data for the I/O cost comparisons.
- `recall_experiment.py` generates the data for the recall experiments.

#### Helper code
- `bigann_datasets.py` and `bigann_dataset_io.py` contain helper code from the big-ann-benchmarks library (https://github.com/harsha-simhadri/big-ann-benchmarks/tree/main). We use this code to download and manage the static vector benchmarks. We do not claim credit for this code and acknowledge the authors for their work. The code is included here for self-containedness of this submission only. It is publicly available under the MIT license.