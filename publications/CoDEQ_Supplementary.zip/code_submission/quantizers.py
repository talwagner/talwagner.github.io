import numpy as np
import bisect
import faiss
import time
import torch
from concurrent.futures import ThreadPoolExecutor
import multiprocessing
from collections import deque, Counter
from scipy.stats import special_ortho_group
from sklearn.cluster import KMeans
from typing import List, Tuple


class ObliviousQuantizer:
    def __init__(self, dataset_size, dataset_dim, num_blocks, bits_per_block, distance_type='L2'):
        self.dataset_size = dataset_size
        self.dataset_dim = dataset_dim
        self.block_dim = dataset_dim // num_blocks
        self.num_blocks = num_blocks
        self.bits = bits_per_block
        self.distance_type = distance_type
        if self.distance_type == 'L2':
            self.flat = faiss.IndexFlatL2(dataset_dim)
        elif self.distance_type == 'IP':
            self.flat = faiss.IndexFlatIP(dataset_dim)

        self.random_thresholds = [np.random.normal(0,1, (self.block_dim, self.bits)) for i in range(self.num_blocks) ]

        self.dataset = np.empty((self.dataset_size, self.dataset_dim))
        self.dataset[:] = np.nan
        self.dataset_tuple = []
        self.active_indices = []

        self.encoded_dataset = np.empty((self.dataset_size, self.num_blocks))
        self.encoded_dataset[:] = np.nan
        self.code_books = [np.zeros((int(2 ** self.bits), self.block_dim)) for i in range(self.num_blocks)]
        self.code_books_counts = [np.zeros((int(2 ** self.bits), 1)) for i in range(self.num_blocks)]


    def initialize(self, dataset_tuple):
        if (self.dataset_dim % self.num_blocks != 0):
         raise Exception("please choosenum_blocks so that data dim is divisible by num_blocks")

        self.dataset_tuple  = dataset_tuple
        for data_point in dataset_tuple:
            self.dataset[data_point[1], :] = data_point[0]
            self.active_indices.append(data_point[1])
        self.active_indices.sort()

        for i in range(self.num_blocks): 
            #grab the block
            block_dataset = self.dataset[self.active_indices,i*self.block_dim:(i+1)*self.block_dim] 

            #prepare the codebook for this block
            block_code_book = self.code_books[i]
            block_code_book_count = self.code_books_counts[i]
            
            #Compute the encoding of each point
            encoded_block_dataset = np.matmul(block_dataset, self.random_thresholds[i])
            encoded_block_dataset  = np.where(encoded_block_dataset >=0 , 1 , 0).astype(int)

            # Convert binary row to an integer (considering binary values)
            unique_integers = encoded_block_dataset.dot(1 << np.arange(encoded_block_dataset.shape[1])[::-1])

            # add this to encoded dataset
            self.encoded_dataset[self.active_indices, i] = unique_integers

            # Find unique rows and their indices
            unique_patterns = np.unique(unique_integers)

            # Group rows by their unique pattern
            rows_by_pattern = [np.where(unique_integers == i)[0] for i in unique_patterns]

            #Compute the averages of each point in the same encoding
            for j in range(unique_patterns.shape[0]):

                #grab subvectors that achieve the jth unique pattern 
                indices = rows_by_pattern[j]

                #compute average of these vectors
                average = np.average(block_dataset[indices,:], axis=0)

                #replace their quantization with the average
                block_code_book[int(unique_patterns[j]),:]= average

                #update the count of vectors that map to this code
                block_code_book_count[int(unique_patterns[j]), 0] = indices.shape[0]


    def bulk_add(self, inserted_data_points):
        # Method to add data and quantize

        insert_indices = []
        for point in inserted_data_points:
            self.dataset[point[1], :] = point[0]
            self.active_indices.append(point[1])
            insert_indices.append(point[1])
        
        self.active_indices.sort()
        insert_indices.sort()

        sorted_inserted_data_points = inserted_data_points[:]
        sorted_inserted_data_points.sort(key=lambda x : x[1])

        #compute encoding of new points
        for i in range(self.num_blocks): 
            #prepare the codebook for this block
            block_code_book = self.code_books[i]
            block_code_book_count = self.code_books_counts[i]

            #grab block dataset
            block_dataset = self.dataset[insert_indices, i*self.block_dim:(i+1)*self.block_dim]

            encoded_block_dataset = np.matmul(block_dataset, self.random_thresholds[i])
            encoded_block_dataset  = np.where(encoded_block_dataset >=0 , 1 , 0).astype(int)

            unique_integers = encoded_block_dataset.dot(1 << np.arange(encoded_block_dataset.shape[1])[::-1])

            count = 0
            for point in sorted_inserted_data_points:
                self.encoded_dataset[point[1], i] = unique_integers[count]
                curr_index = int(self.encoded_dataset[point[1], i])
                block_vector = point[0][i*self.block_dim:(i+1)*self.block_dim]
                block_code_book[curr_index, :] =  (block_code_book_count[curr_index, :]*block_code_book[curr_index, :] + block_vector)/(block_code_book_count[curr_index, :]+1)
                block_code_book_count[curr_index, :] += 1
                count += 1


    def bulk_delete(self, deleted_data_points):

        #update dataset 
        for point in deleted_data_points:
            self.dataset[point[1], :] = np.nan
            self.active_indices.remove(point[1])
        
        self.active_indices.sort()

        #compute encoding of new points
        for i in range(self.num_blocks): 
            #prepare the codebook for this block
            block_code_book = self.code_books[i]
            block_code_book_count = self.code_books_counts[i]
            

            #naively compute closest clusters for each point
            for point in deleted_data_points:
                index = self.encoded_dataset[int(point[1]), i].astype(int)
                block_vector = point[0][i*self.block_dim:(i+1)*self.block_dim]
                
                #update codebook and codebook count
                if block_code_book_count[index, :]==1:
                    block_code_book[index, :] = 0
                else:
                    block_code_book[index, :] =  (block_code_book_count[index, :]*block_code_book[index, :] - block_vector)/(block_code_book_count[index, :]-1)
                
                block_code_book_count[index, :] -= 1


    def populate_flat(self):
        # method to populate or update the FAISS flat index 

        #create FAISS flat index
        if self.distance_type == 'L2':
            temp = faiss.IndexFlatL2(self.dataset_dim)
        elif self.distance_type == 'IP':
            temp = faiss.IndexFlatIP(self.dataset_dim)

        ngpus = faiss.get_num_gpus()
        if ngpus > 0:
            self.flat = faiss.index_cpu_to_all_gpus(temp)
        else:
            self.flat = temp

        #create dummy quantized dataset
        quantized_dataset = np.zeros((len(self.active_indices), self.dataset_dim))

        #compute the encoded dataset 
        for i in range(self.num_blocks): 

            #prepare block quantized and encoded datasets
            block_quantized_dataset = quantized_dataset[:, i*self.block_dim:(i+1)*self.block_dim]
            block_encoded_dataset = self.encoded_dataset[self.active_indices, i]

            #prepare the codebook for this block
            block_code_book = self.code_books[i]

            # Find unique values and their indices
            unique_patterns = np.unique(block_encoded_dataset)

            # Group rows by their unique pattern
            rows_by_pattern = [np.where(block_encoded_dataset == i)[0] for i in unique_patterns]

            #Compute the averages of each point in the same encoding
            for j in range(unique_patterns.shape[0]): #subtract 1 to ignore the np.nan entries

                if unique_patterns[j] == np.nan: #skip nan 
                    raise Exception("Hmm, there should be no nans since we indexed into active indices...")

                #grab subvectors that achieve the jth unique pattern 
                indices = rows_by_pattern[j]

                #populate quantized dataset with 
                block_quantized_dataset[indices] = block_code_book[int(unique_patterns[j]),:]
    
        #finally, populate flat index
        self.flat.add(quantized_dataset) 


    def search(self, queries, top_k):
        #method to search once flat index has  been populated has 
        return self.flat.search(queries, top_k)
    

class FrozenPQQuantizer:
    def __init__(self, dataset_size, dataset_dim, num_blocks, bits_per_block, distance_type='L2'):
        self.dataset_size = dataset_size 
        self.dataset_dim = dataset_dim
        self.block_dim = dataset_dim // num_blocks
        self.num_blocks = num_blocks
        self.bits = bits_per_block
        self.flat = None
        self.distance_type = distance_type

        self.centroids = {}
        self.dataset = np.empty((self.dataset_size, self.dataset_dim))
        self.dataset[:] = np.nan
        self.dataset_tuple = []
        self.active_indices = []
        self.encoded_dataset = np.empty((self.dataset_size, self.num_blocks))
        self.encoded_dataset[:] = np.nan
        self.code_books = [np.zeros((int(2 ** self.bits), self.block_dim)) for i in range(self.num_blocks)]
        self.code_books_counts = [np.zeros((int(2 ** self.bits), 1)) for i in range(self.num_blocks)]


    def initialize(self, dataset_tuple):
        # Encode every block and learn the codebook
        if (self.dataset_dim % self.num_blocks != 0):
         raise Exception("please choosenum_blocks so that data dim is divisible by num_blocks")

        self.dataset_tuple  = dataset_tuple

        #fill in np style dataset
        for data_point in dataset_tuple:
            self.dataset[data_point[1], :] = data_point[0]
            self.active_indices.append(data_point[1])

        self.active_indices.sort()
        for i in range(self.num_blocks): 
            # #prepare the block dataset
            block_dataset = self.dataset[self.active_indices, i*self.block_dim:(i+1)*self.block_dim]

            #prepare the codebook for this block
            block_code_book = self.code_books[i]
            block_code_book_count = self.code_books_counts[i]

            #train K-means 
            kmeans = faiss.Kmeans(self.block_dim, 2**self.bits, niter= 5, gpu=True, verbose=False) 
            kmeans.train(block_dataset)
    
            #store centroids
            self.centroids[str(i)] = kmeans.centroids

            #populate code book
            for j in range(int(2**self.bits)):
                block_code_book[j, :] = kmeans.centroids[j,:]

            # search structure to find closest centroid
            temp_index = faiss.IndexFlatL2(self.block_dim) 
            temp_index.add(self.centroids[str(i)])

            ngpus = faiss.get_num_gpus()
            if ngpus > 0:
                gpu_temp_index = faiss.index_cpu_to_all_gpus(temp_index) # build the gpu index and search the closest centroid
                _, closest_clusters = gpu_temp_index.search(block_dataset,1)
            else:
                _, closest_clusters = temp_index.search(block_dataset,1)

            #update encoding
            for j, point in enumerate(self.dataset_tuple): # get closest centroid
                closest_cluster_id = closest_clusters[j]

                #update counts
                block_code_book_count[closest_cluster_id, :] += 1

                #update the encoding of this point in this block
                self.encoded_dataset[int(point[1]), i] = closest_cluster_id


    def bulk_add(self, inserted_data_points):
        # add and encode points without changing centroids
        insert_indices = []
        for point in inserted_data_points:
            self.dataset[point[1], :] = point[0]
            self.active_indices.append(point[1])
            insert_indices.append(point[1])

        self.active_indices.sort()
        insert_indices.sort()

        #compute encoding of new points
        for i in range(self.num_blocks): 
            block_code_book = self.code_books[i]
            temp_index = faiss.IndexFlatL2(self.block_dim) # search structure to find closest centroid
            temp_index.add(block_code_book)

            for point in inserted_data_points: # get closest centroid
                block_vector = point[0][i*self.block_dim:(i+1)*self.block_dim]
                _, closest_clusters = temp_index.search(np.vstack((block_vector, np.ones_like(block_vector))), 1)
                closest_cluster_id = closest_clusters[0]

                #update the encoding of this point in this block
                self.encoded_dataset[int(point[1]), i] = closest_cluster_id


    def bulk_delete(self, deleted_data_points):
        # delete points without changing centroids
        for point in deleted_data_points:
            self.dataset[point[1], :] = np.nan
            self.active_indices.remove(point[1])
        
        self.active_indices.sort()


    def populate_flat(self):
        # method to populate or update the FAISS flat index 

        #create FAISS flat index
        if self.distance_type == 'L2':
            temp = faiss.IndexFlatL2(self.dataset_dim)
        elif self.distance_type == 'IP':
            temp = faiss.IndexFlatIP(self.dataset_dim)

        ngpus = faiss.get_num_gpus()
        if ngpus > 0:
            self.flat = faiss.index_cpu_to_all_gpus(temp)
        else:
            self.flat = temp

        #create dummy quantized dataset
        quantized_dataset = np.zeros((len(self.active_indices), self.dataset_dim))

        #compute the encoded dataset 
        for i in range(self.num_blocks): 

            #prepare block quantized and encoded datasets
            block_quantized_dataset = quantized_dataset[:, i*self.block_dim:(i+1)*self.block_dim]
            block_encoded_dataset = self.encoded_dataset[self.active_indices, i]

            #prepare the codebook for this block
            block_code_book = self.code_books[i]

            # Find unique values and their indices
            unique_patterns = np.unique(block_encoded_dataset)

            # Group rows by their unique pattern
            rows_by_pattern = [np.where(block_encoded_dataset == i)[0] for i in unique_patterns]

            #Compute the averages of each point in the same encoding
            for j in range(unique_patterns.shape[0]):

                #grab subvectors that achieve the jth unique pattern 
                indices = rows_by_pattern[j]

                #populate quantized dataset with 
                block_quantized_dataset[indices] = block_code_book[int(unique_patterns[j]),:]

        #finally, populate flat index
        self.flat.add(quantized_dataset) 


    def search(self, queries, top_k):
        # method to search once flat index has  been populated has 
        return self.flat.search(queries, top_k)


class OnlinePQQuantizer:
    def __init__(self, dataset_size, dataset_dim, num_blocks, bits_per_block, distance_type='L2'):
        self.dataset_size = dataset_size
        self.dataset_dim = dataset_dim
        self.block_dim = dataset_dim // num_blocks
        self.num_blocks = num_blocks
        self.bits = bits_per_block
        self.flat = None
        self.distance_type = distance_type

        self.centroids = {}
        self.dataset = np.empty((self.dataset_size, self.dataset_dim))
        self.dataset[:] = np.nan
        self.dataset_tuple = []
        self.active_indices = []
        self.encoded_dataset = np.empty((self.dataset_size, self.num_blocks))
        self.encoded_dataset[:] = np.nan
        self.code_books = [np.zeros((int(2 ** self.bits), self.block_dim)) for i in range(self.num_blocks)]
        self.code_books_counts = [np.zeros((int(2 ** self.bits), 1)) for i in range(self.num_blocks)]


    def initialize(self, dataset_tuple):
        # Encode every block and learn the codebook
        if (self.dataset_dim % self.num_blocks != 0):
         raise Exception("please choosenum_blocks so that data dim is divisible by num_blocks")

        self.dataset_tuple  = dataset_tuple

        #fill in np style dataset
        for data_point in dataset_tuple:
            self.dataset[data_point[1], :] = data_point[0]
            self.active_indices.append(data_point[1])

        self.active_indices.sort()
        for i in range(self.num_blocks): 
            # #prepare the block dataset
            block_dataset = self.dataset[self.active_indices, i*self.block_dim:(i+1)*self.block_dim]

            #prepare the codebook for this block
            block_code_book = self.code_books[i]
            block_code_book_count = self.code_books_counts[i]

            #train K-means 
            kmeans = faiss.Kmeans(self.block_dim, 2**self.bits, niter= 5, gpu=True, verbose = False)
            kmeans.train(block_dataset)
    
            #store centroids
            self.centroids[str(i)] = kmeans.centroids

            #naively compute closest clusters for each point
            for j in range(len(self.active_indices)):
                point = block_dataset[j, :]
                closest_cluster_id = 1000000 #large number
                min_dist = np.inf
                count = 0
                for centroid in  self.centroids[str(i)]:
                    if np.linalg.norm(centroid-point) < min_dist:
                        min_dist = np.linalg.norm(centroid-point)
                        closest_cluster_id = count
                    count += 1

                #update the econding of this point in this block
                self.encoded_dataset[self.active_indices[j], i] = closest_cluster_id

                #update codebook and codebook count
                block_code_book[closest_cluster_id, :] =  (block_code_book_count[closest_cluster_id, :]*block_code_book[closest_cluster_id, :] + point)/(block_code_book_count[closest_cluster_id, :]+1)
                block_code_book_count[closest_cluster_id, :] += 1
        
    def bulk_add(self, inserted_data_points):
        # Method to add data and quantize

        #update dataset 
        insert_indices = []
        for point in inserted_data_points:
            self.dataset[point[1], :] = point[0]
            self.active_indices.append(point[1])
            insert_indices.append(point[1])
        
        self.active_indices.sort()
        insert_indices.sort()

        sorted_inserted_data_points = inserted_data_points[:]
        sorted_inserted_data_points.sort(key=lambda x : x[1])

        #compute encoding of new points
        for i in range(self.num_blocks): 
            #prepare the codebook for this block
            block_code_book = self.code_books[i]
            block_code_book_count = self.code_books_counts[i]
            #naively compute closest clusters for each point
            for point in inserted_data_points:
                block_vector = point[0][i*self.block_dim:(i+1)*self.block_dim]
                temp_index = faiss.IndexFlatL2(self.block_dim)
                temp_index.add(block_code_book)
                _, closest_clusters = temp_index.search(np.vstack((block_vector, np.ones_like(block_vector))),1)
                closest_cluster_id = closest_clusters[0]

                #update the econding of this point in this block
                self.encoded_dataset[int(point[1]), i] = closest_cluster_id

                #update codebook and codebook count
                block_code_book[closest_cluster_id, :] =  (block_code_book_count[closest_cluster_id, :]*block_code_book[closest_cluster_id, :] + block_vector)/(block_code_book_count[closest_cluster_id, :]+1)
                block_code_book_count[closest_cluster_id, :] += 1


    def fast_bulk_add(self, inserted_data_points):
        # add and encode points without changing centroids
        insert_indices = []
        for point in inserted_data_points:
            self.dataset[point[1], :] = point[0]
            self.active_indices.append(point[1])
            insert_indices.append(point[1])

        self.active_indices.sort()
        # insert_indices.sort()

        #compute encoding of new points
        for i in range(self.num_blocks): 
            block_code_book = self.code_books[i]
            temp_index = faiss.IndexFlatL2(self.block_dim) # search structure to find closest centroid
            temp_index.add(block_code_book)

            ngpus = faiss.get_num_gpus()
            if ngpus > 0:
                gpu_temp_index = faiss.index_cpu_to_all_gpus(temp_index) # build the gpu index
                _, closest_clusters = gpu_temp_index.search(self.dataset[insert_indices, i*self.block_dim:(i+1)*self.block_dim],1)
            
            else:
                _, closest_clusters = temp_index.search(self.dataset[insert_indices, i*self.block_dim:(i+1)*self.block_dim],1)

            for j, point in enumerate(inserted_data_points): # get closest centroid
                # block_vector = point[0][i*self.block_dim:(i+1)*self.block_dim]
                # _, closest_clusters = temp_index.search(np.vstack((block_vector, np.ones_like(block_vector))), 1) # what is the all-ones vector doing here?
                closest_cluster_id = closest_clusters[j]

                #update the encoding of this point in this block
                self.encoded_dataset[int(point[1]), i] = closest_cluster_id


    def bulk_delete(self, deleted_data_points):

        #update dataset 
        for point in deleted_data_points:
            self.dataset[point[1], :] = np.nan
            self.active_indices.remove(point[1])
        
        self.active_indices.sort()

        #compute encoding of new points
        for i in range(self.num_blocks): 
            #prepare the codebook for this block
            block_code_book = self.code_books[i]
            block_code_book_count = self.code_books_counts[i]

            for point in deleted_data_points:
                closest_cluster_id = self.encoded_dataset[int(point[1]), i].astype(int)
                block_vector = point[0][i*self.block_dim:(i+1)*self.block_dim]
               
                #update codebook and codebook count
                if block_code_book_count[closest_cluster_id, :]==1:
                    block_code_book[closest_cluster_id, :] = 0
                else:
                    block_code_book[closest_cluster_id, :] =  (block_code_book_count[closest_cluster_id, :]*block_code_book[closest_cluster_id, :] - block_vector)/(block_code_book_count[closest_cluster_id, :]-1)
                
                block_code_book_count[closest_cluster_id, :] -= 1


    def populate_flat(self):
        #create FAISS flat index
        if self.distance_type == 'L2':
            temp = faiss.IndexFlatL2(self.dataset_dim)
        elif self.distance_type == 'IP':
            temp = faiss.IndexFlatIP(self.dataset_dim)

        ngpus = faiss.get_num_gpus()
        if ngpus > 0:
            self.flat = faiss.index_cpu_to_all_gpus(temp)
        else:
            self.flat = temp

        #create dummy quantized dataset
        quantized_dataset = np.zeros((len(self.active_indices), self.dataset_dim))

        #compute the encoded dataset 
        for i in range(self.num_blocks): 

            #prepare block quantized and encoded datasets
            block_quantized_dataset = quantized_dataset[:, i*self.block_dim:(i+1)*self.block_dim]
            block_encoded_dataset = self.encoded_dataset[self.active_indices, i]

            #prepare the codebook for this block
            block_code_book = self.code_books[i]

            # Find unique values and their indices
            unique_patterns = np.unique(block_encoded_dataset)

            # Group rows by their unique pattern
            rows_by_pattern = [np.where(block_encoded_dataset == i)[0] for i in unique_patterns]

            #Compute the averages of each point in the same encoding
            for j in range(unique_patterns.shape[0]):

                #grab subvectors that achieve the jth unique pattern 
                indices = rows_by_pattern[j]

                #populate quantized dataset with 
                block_quantized_dataset[indices] = block_code_book[int(unique_patterns[j]),:]

        #finally, populate flat index
        self.flat.add(quantized_dataset) 

    def search(self, queries, top_k):
        #method to search once flat index has  been populated has 
        return self.flat.search(queries, top_k)


class DeDriftPQQuantizer:
    def __init__(self, 
                 dataset_size, 
                 dataset_dim, 
                 num_blocks, 
                 bits_per_block,
                 num_recluster,
                 max_recluster_fraction = 0.2,
                 distance_type = 'L2'):
        
        self.dataset_size = dataset_size 
        self.dataset_dim = dataset_dim
        self.block_dim = dataset_dim // num_blocks
        self.num_blocks = num_blocks
        self.bits = bits_per_block
        self.flat = None
        self.distance_type = distance_type

        # data
        self.dataset = np.empty((self.dataset_size, self.dataset_dim))
        self.dataset[:] = np.nan
        self.dataset_tuple = []
        self.active_indices = []
        self.encoded_dataset = np.empty((self.dataset_size, self.num_blocks))
        self.encoded_dataset[:] = np.nan

        # structures maintained per block
        self.code_books = [{} for i in range(self.num_blocks)]
        
        # dedrift parameters
        self.num_clusters = 2**self.bits
        self.num_recluster = num_recluster
        self.max_recluster_fraction = max_recluster_fraction
        assert self.num_recluster < int(self.num_clusters * self.max_recluster_fraction)


    def initialize(self, initial_dataset: List[Tuple[np.array, int]]):

        if (self.dataset_dim % self.num_blocks != 0):
         raise Exception("please choosenum_blocks so that data dim is divisible by num_blocks")

        # populate initial data
        self.dataset_tuple  = initial_dataset
        for data_point in initial_dataset:
            self.dataset[data_point[1], :] = data_point[0]
            self.active_indices.append(data_point[1])
        self.active_indices.sort()

        for i in range(self.num_blocks): 
            
            # extract subvector dataset
            block_dataset = self.dataset[self.active_indices, i*self.block_dim:(i+1)*self.block_dim]

            # fit kmeans
            clustering = KMeans(n_clusters=self.num_clusters, max_iter=5).fit(block_dataset)

            # save kmeans centroids as codebook and update encoded dataset
            centroids = clustering.cluster_centers_
            self.code_books[i] = {int(j): centroids[j, :] for j in range(centroids.shape[0])}
            self.encoded_dataset[self.active_indices, i] = clustering.predict(block_dataset)


    def update(self, inserts, deletes, apply_dedrift=True):

        # update dataset and active indices with inserts and deletes
        insert_indices = []
        for point in inserts:
            self.dataset[point[1], :] = point[0]
            self.active_indices.append(point[1])
            insert_indices.append(point[1])
        
        self.active_indices.sort()
        insert_indices.sort()

        for point in deletes:
            self.dataset[point[1], :] = np.nan
            self.active_indices.remove(point[1])
        
        self.active_indices.sort()

        update_ids = set()
        # run de-drift updates in each block
        for i in range(self.num_blocks): 

            # extract subvector dataset
            block_dataset = self.dataset[self.active_indices, i*self.block_dim:(i+1)*self.block_dim]

            # map inserted points to existing clusters
            for ix in insert_indices:
                subvec = self.dataset[ix, i*self.block_dim:(i+1)*self.block_dim]
                subvec_id = -1
                dist = 1e20
                for id, centroid in self.code_books[i].items():
                    if np.linalg.norm(subvec-centroid) < dist:
                        subvec_id = id
                        dist = np.linalg.norm(subvec-centroid)
                self.encoded_dataset[ix, i] = subvec_id

            if apply_dedrift:
                # apply "dedrift-split" re-clustering:
                block_ids = self.encoded_dataset[self.active_indices, i].astype(int)
                counts = Counter(block_ids)
                zero_clusters = [k for k in self.code_books[i].keys() if k not in list(counts)]
                for z in zero_clusters:
                    counts[z] = 0 # add zero counts for any ids in codebook that aren't actively used


                ### collect data from smallest and largest current clusters
                most_common_ids = [x[0] for x in counts.most_common()[:self.num_recluster]]
                most_common_count = sum([x[1] for x in counts.most_common()[:self.num_recluster]])
                k2 = np.ceil(most_common_count / np.median([x[1] for x in (+counts).most_common()])).astype(int)

                # limit the max number of clusters reassinged in a single iteration
                if k2 > int(self.max_recluster_fraction * self.num_clusters):
                    k2 = int(self.max_recluster_fraction * self.num_clusters)

                least_common_ids = [x[0] for x in counts.most_common()[-(k2-self.num_recluster):]]
                most_common_ixs = np.sum([block_ids == x for x in most_common_ids], axis=0).astype(bool)
                least_common_ixs = np.sum([block_ids == x for x in least_common_ids], axis=0).astype(bool)

                recluster_ixs = np.logical_or(most_common_ixs, least_common_ixs)
                recluster_data = block_dataset[recluster_ixs, :]

                update_ids.update(set([i for i,x in enumerate(recluster_ixs) if x]))

                ### perform reclustering and merge with old clusters
                new_kmeans = KMeans(n_clusters=k2, max_iter=5).fit(recluster_data)

                # update codebook
                for id in most_common_ids + least_common_ids:
                    self.code_books[i].pop(id) # remove old clusters
                new_centroids = new_kmeans.cluster_centers_

                id_offset = max(block_ids) + 1 # avoid collision with prev cluster ids
                for j in range(new_centroids.shape[0]):
                    self.code_books[i][j+id_offset] = new_centroids[j, :]
        
                # update encoded data
                new_ids = new_kmeans.predict(recluster_data) + id_offset 
                block_ids[recluster_ixs] = new_ids
                self.encoded_dataset[self.active_indices, i] = block_ids


    def populate_flat(self):

        if self.distance_type == 'L2':
            temp = faiss.IndexFlatL2(self.dataset_dim)
        elif self.distance_type == 'IP':
            temp = faiss.IndexFlatIP(self.dataset_dim)

        ngpus = faiss.get_num_gpus()
        if ngpus > 0:
            self.flat = faiss.index_cpu_to_all_gpus(temp)
        else:
            self.flat = temp

        quantized_dataset = np.zeros((len(self.active_indices), self.dataset_dim))

        # build quantized dataset
        for i in range(self.num_blocks):
            ids = self.encoded_dataset[self.active_indices, i]
            block_vec = np.stack([self.code_books[i][ix] for ix in ids]) # n x block_dim
            quantized_dataset[:, (i*self.block_dim):((i+1)*self.block_dim)] = block_vec

        # populate the flat l2 index
        self.flat.add(quantized_dataset) 


    def search(self, queries, top_k):
        '''
        search flat index of quantized points for exact (quantized) nearest neighbors
        '''
        return self.flat.search(queries, top_k)
    

class KDTreeQuantizer:
    def __init__(self, 
                 dataset_size, 
                 dataset_dim, 
                 num_blocks, 
                 bits_per_block, 
                 random_rotation=False,
                 distance_type='L2'):
        
        self.dataset_size = dataset_size 
        self.dataset_dim = dataset_dim
        self.block_dim = dataset_dim // num_blocks
        self.num_blocks = num_blocks
        self.bits = bits_per_block
        self.flat = None
        self.distance_type = distance_type

        self.random_rotation = random_rotation
        self.block_random_rotations = {} 
        self.trees = {}

        self.dimensions = [np.concatenate([np.random.permutation(self.block_dim) for _ in range((self.bits + self.block_dim - 1) // self.block_dim)])[:self.bits] for i in range(self.num_blocks)]
        self.dataset = np.zeros((self.dataset_size, self.dataset_dim))
        self.dataset_tuple = []
        self.active_indices = []
        self.encoded_dataset = np.empty((self.dataset_size, self.num_blocks))
        self.encoded_dataset[:] = np.nan
        self.code_books = [np.zeros((int(2 ** self.bits), self.block_dim)) for i in range(self.num_blocks)]
        self.code_books_counts = [np.zeros((int(2 ** self.bits), 1)) for i in range(self.num_blocks)]


    def initialize(self, dataset_tuple):
        # Encode every block and learn the codebook
        if (self.dataset_dim % self.num_blocks != 0):
            raise Exception("please choosenum_blocks so that data dim is divisible by num_blocks")

        self.dataset_tuple  = dataset_tuple

        #fill in np style dataset
        for data_point in dataset_tuple:
            self.dataset[data_point[1], :] = data_point[0]
            self.active_indices.append(data_point[1])

        self.active_indices.sort()
        block_dataset_tuple = {}
        for i in range(self.num_blocks): 
            # #prepare the block dataset
            block_dataset_tuple[str(i)] = []

            if self.random_rotation: # Prepare the random rotation
                random_matrix = special_ortho_group.rvs(self.block_dim)
                self.block_random_rotations[str(i)] = random_matrix
                for data_point in self.dataset_tuple:
                    rotated_data_point = np.matmul(data_point[0][i*self.block_dim:(i+1)*self.block_dim], random_matrix)
                    block_dataset_tuple[str(i)].append((rotated_data_point, data_point[1]))

            else:
                for data_point in self.dataset_tuple:
                    block_dataset_tuple[str(i)].append((data_point[0][i*self.block_dim:(i+1)*self.block_dim], data_point[1]))

            #prepare the codebook for this block
            block_code_book = self.code_books[i]
            block_code_book_count = self.code_books_counts[i]

            # train KD tree
            self.trees[str(i)] = kd_tree(block_dataset_tuple[str(i)], self.dimensions[i], self.bits)

            # naively compute encoding from leaf partitioning
            count = 0
            for leaf in self.trees[str(i)].leaves:
                #grad indices in for this codeword
                leaf_indices = list(leaf.indices_dict.keys())

                #update encoding
                self.encoded_dataset[leaf_indices, i] = count

                #update codebook and codebook count
                block_code_book[count, :] = np.average(self.dataset[leaf_indices, i*self.block_dim:(i+1)*self.block_dim], axis=0)
                block_code_book_count[count, :] = len(leaf_indices)

                #increment codeword
                count = count + 1


    def populate_flat(self):
        # method to populate or update the FAISS flat index 

        #create FAISS flat index
        if self.distance_type == 'L2':
            temp = faiss.IndexFlatL2(self.dataset_dim)
        elif self.distance_type == 'IP':
            temp = faiss.IndexFlatIP(self.dataset_dim)

        ngpus = faiss.get_num_gpus()
        if ngpus > 0:
            self.flat = faiss.index_cpu_to_all_gpus(temp)
        else:
            self.flat = temp

        #create dummy quantized dataset
        quantized_dataset = np.zeros((len(self.active_indices), self.dataset_dim))

        #compute the encoded dataset 
        for i in range(self.num_blocks): 

            #prepare block quantized and encoded datasets
            block_quantized_dataset = quantized_dataset[:, i*self.block_dim:(i+1)*self.block_dim]
            block_encoded_dataset = self.encoded_dataset[self.active_indices, i]

            #prepare the codebook for this block
            block_code_book = self.code_books[i]

            # Find unique values and their indices
            unique_patterns = np.unique(block_encoded_dataset)

            # Group rows by their unique pattern
            rows_by_pattern = [np.where(block_encoded_dataset == i)[0] for i in unique_patterns]

            #Compute the averages of each point in the same encoding
            for j in range(unique_patterns.shape[0]):

                #grab subvectors that achieve the jth unique pattern 
                indices = rows_by_pattern[j]

                #populate quantized dataset with 
                block_quantized_dataset[indices] = block_code_book[int(unique_patterns[j]),:]

        #finally, populate flat index
        self.flat.add(quantized_dataset) 

    def search(self, queries, top_k):
        #method to search once flat index has  been populated has 
        return self.flat.search(queries, top_k)
    

class kd_tree:
    def __init__(self, data, dimensions, depth):
        self.max_depth = depth
        self.root = None
        self.leaves = []
        self.create_tree(data, dimensions)


    def create_tree(self, data, dimensions):

        self.root = Node(data, dimensions, 0, self.max_depth)
        nodes = [(self.root, 0)]

        while len(nodes) != 0:
            current_node, current_depth = nodes.pop(0)
            current_data = current_node.data
            current_dimensions = current_node.dimensions

            if current_depth < self.max_depth:
                current_data.sort(key=lambda x : x[0][int(current_dimensions[0])])
                left_data = current_data[:int(np.ceil((len(current_data)-1)/2))]
                right_data = current_data[int(np.ceil((len(current_data)-1)/2)):]
                current_node.insert_children(left_data, right_data, current_dimensions[1:], current_depth + 1, self.max_depth)
                nodes.append((current_node.left, current_depth + 1))
                nodes.append((current_node.right, current_depth + 1))

            else: # make easy access to leaves
                self.leaves.append(current_node)

    def update_tree(self, inserts, deletes):
        self.root.update(inserts, deletes)

    def print_tree(self):
        if not self.root:
            return

        queue = deque([(self.root, 0)])
        current_level = 0
        level_nodes = []

        while queue:
            node, level = queue.popleft()
            
            if level > current_level:
                print("Level", current_level, ":", level_nodes)
                level_nodes = []
                current_level = level

            level_nodes.append(list(node.indices_dict.keys()))
            
            if node.left:
                queue.append((node.left, level + 1))
            if node.right:
                queue.append((node.right, level + 1))

        if level_nodes: # Print the last level nodes
            print("Level", current_level, ":", level_nodes)


class Node:
    def __init__(self, data, dimensions, my_depth, max_depth):
        self.left = None
        self.right = None
        self.dimensions = dimensions 
        self.data = data
        self.indices_dict = {point[1] : point for point in data}
        self.my_depth = my_depth
        self.max_depth = max_depth

    def insert_children(self, left_data, right_data, dimensions, my_depth, max_depth):
        self.left = Node(left_data, dimensions, my_depth, max_depth)
        self.right = Node(right_data, dimensions, my_depth, max_depth)

    def fast_update(self, inserts, deletes):

        if self.my_depth < self.max_depth:
            cut_dim = self.dimensions[0]
            #compute old left and right sets
            old_median_index = int(np.ceil((len(self.data)-1)/2))

            old_left = self.data[:old_median_index]
            old_left_hashable = [(point[0][cut_dim], point[1]) for point in old_left]
            
            old_right = self.data[old_median_index:]
            old_right_hashable = [(point[0][cut_dim], point[1]) for point in old_right]

        if deletes:
            # Remove points that need to be deleted
            for point in deletes:
                if point[1] in self.indices_dict:
                    del self.indices_dict[point[1]]

        if inserts:
            # Insert new points
            for point in inserts:
                self.indices_dict[point[1]] = point
            
        # Reconstruct the data list from the dictionary
        self.data = list(self.indices_dict.values())
        if self.my_depth < self.max_depth:
            self.data.sort(key=lambda x: x[0][cut_dim])
        else:
            self.data.sort(key=lambda x: x[1])

        if self.my_depth < self.max_depth:

            # Compute new left and right sets 
            new_median_index =  int(np.ceil((len(self.data)-1)/2))
            new_left = self.data[:new_median_index]
            new_left_hashable = [(point[0][cut_dim], point[1]) for point in new_left]
            new_right = self.data[new_median_index:]
            new_right_hashable = [(point[0][cut_dim], point[1]) for point in new_right]

            # Use hashable representations to find set diferences and convert to list
            temp_left_deletes = list(set(old_left_hashable) - set(new_left_hashable))
            temp_left_inserts = list(set(new_left_hashable) - set(old_left_hashable))
            temp_right_deletes = list(set(old_right_hashable) - set(new_right_hashable))
            temp_right_inserts = list(set(new_right_hashable) - set(old_right_hashable))

            # Create a mapping from hashable representation to the original points
            left_delete_dict = {(point[0][cut_dim], point[1]): point for point in old_left}
            left_inserts_dict = {(point[0][cut_dim], point[1]): point for point in new_left}
            right_delete_dict = {(point[0][cut_dim], point[1]): point for point in old_right}
            right_inserts_dict = {(point[0][cut_dim], point[1]): point for point in new_right}

            # Find points in original unhashable data from hashed deletes/inserts
            left_deletes = [left_delete_dict[delete] for delete in temp_left_deletes]
            left_inserts = [left_inserts_dict[insert] for insert in temp_left_inserts]
            right_deletes = [right_delete_dict[delete] for delete in temp_right_deletes]  
            right_inserts = [right_inserts_dict[insert] for insert in temp_right_inserts]

            if(len(left_deletes) > 1 or len(right_deletes) > 1 or len(left_inserts) > 1 or len(right_inserts) > 1):
                raise Exception('more than 1 insert/delete passed!!!')
            # Finally, update children
            self.left.update(left_inserts, left_deletes)
            self.right.update(right_inserts, right_deletes)
